// Package helps to scrape and parse the web data
const { chromium } = require("playwright");
const pool = require("./config/db");

// Function to scrape and store single stock data
const scrapeDataForCompany = async (stock) => {
  // Playwright chromium initial setup
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage();

  try {
    // Construct URL dynamically using stock name
    const url = `https://groww.in/stocks/${stock}`;

    await page.goto(url, {
      waitUntil: "networkidle", // // Wait for network to be idle (meaning the page has fully loaded)
      timeout: 120000, // Timeout after 2 minutes if the page doesn't load
    });

    // $$eval() used to find multiple elements with the CSS selector
    const last_trade = await page.$$eval(
      ".lpu38Pri.valign-wrapper.false.displayBase span", // CSS selector to get last_trade value
      (elements) => elements.map((element) => element.textContent.trim()) // Extract the text content of all matching elements
    );

    //$eval() used to find single element with the CSS selector
    const change_in_per = await page.$eval(
      ".lpu38Day.bodyBaseHeavy",
      (element) => element.textContent
    );

    //Change_in_per is in "-0.90 (0.03%)" formate -0.90 is change
    let change = change_in_per.split(" ")[0];

    // Removing the + sign from positive number and keep sign for negative number
    if (change.split("")[0] == "+") {
      change = change.slice(1);
    } else if (change.split("")[0] == "-") {
      change = change;
    }

    // Converting (0.03%) to 0.03
    let perc = change_in_per.split(" ")[1].slice(1, 5);

    // Converting stock name tata-motors-ltd to tata_motors_ltd as db not support '-' seperated names
    const modified_stock_name = stock.split("-").join("_");

    console.log(`   --- ${modified_stock_name} ---`);
    console.log(
      `last_trade: ${last_trade[1]}  change: ${change}  change_in_per: ${perc}`
    );

    // Query to store data in db
    const query = `INSERT INTO ${modified_stock_name}(last_trade,change,change_in_perc) VALUES($1,$2,$3)`;
    await pool.query(query, [last_trade[1], change, perc]);
  } catch (err) {
    console.error(`Error while loading page for ${stock}:`, err);
  } finally {
    await browser.close(); // Close the browser once scraping is done
  }
};

const scrapeDataForMultipleCompanies = async () => {
  const stocks = [
    "tata-motors-ltd",
    "reliance-industries-ltd",
    "infosys-ltd",
    "tata-consultancy-services-ltd",
    "hdfc-nifty-smallcap-etf",
    "hdfc-bank-ltd",
    "state-bank-of-india",
    "icici-bank-ltd",
    "bajaj-finance-ltd",
    "bajaj-finserv-ltd",
    "larsen-toubro-ltd",
    "itc-ltd",
    "tata-steel-ltd",
    "jsw-steel-ltd",
    "adani-ports-and-special-economic-zone-ltd",
    "adani-enterprises-ltd",
  ];

  // Creating an array of promises for scraping data for each stock
  const scrapePromises = stocks.map(async (stock) => {
    scrapeDataForCompany(stock);
  });

  await Promise.all(scrapePromises); // Wait for all scraping tasks to complete concurrently
};

module.exports = scrapeDataForMultipleCompanies;
