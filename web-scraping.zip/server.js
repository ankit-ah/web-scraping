const express = require("express");
const cron = require("node-cron");

const app = express();
const scrapeDataForMultipleCompanies = require("./scrape");
const sgxScrape = require("./sgxscrape");
const db = require("./config/db");

// Middleware to parse JSON requests
app.use(express.json());

// Cron job to scrape SGX data every minute
cron.schedule("* * * * *", async () => {
  const date = new Date();
  try {
    await sgxScrape();
    console.log(`SGX Scrape - Time: ${date.getHours()}:${date.getMinutes()}`);
  } catch (err) {
    console.error("Error scraping SGX:", err);
  }
});

// Cron job to scrape data for multiple companies every minute
cron.schedule("* * * * *", async () => {
  const date = new Date();
  try {
    await scrapeDataForMultipleCompanies();
    console.log(`Multiple Companies Scrape - Time: ${date.getHours()}:${date.getMinutes()}`);
  } catch (err) {
    console.error("Error scraping data for multiple companies:", err);
  }
});

// Start the Express server and connect to the database
app.listen(5000, () => {
  db.connect();
  console.log("Server is running on http://localhost:5000");
});
